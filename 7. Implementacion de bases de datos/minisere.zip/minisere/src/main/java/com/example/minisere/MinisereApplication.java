package com.example.minisere;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinisereApplication {

	public static void main(String[] args) {
		SpringApplication.run(MinisereApplication.class, args);
	}

}
