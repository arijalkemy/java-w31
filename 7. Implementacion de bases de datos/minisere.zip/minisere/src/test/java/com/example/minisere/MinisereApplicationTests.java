package com.example.minisere;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinisereApplicationTests {

	@Test
	void contextLoads() {
	}

}
