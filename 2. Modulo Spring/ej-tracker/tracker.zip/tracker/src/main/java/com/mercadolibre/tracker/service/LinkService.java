package com.mercadolibre.tracker.service;

import com.mercadolibre.tracker.dto.RequestLinkDto;
import com.mercadolibre.tracker.dto.ResponseLinkDto;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

public interface LinkService {
    ResponseLinkDto createLink(RequestLinkDto requestLink);

    ResponseLinkDto redirect(String linkId)
}
