package com.mercadolibre.tracker.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

public class RequestLinkDto {
    private String url;

    public RequestLinkDto(String url) {
        this.url = url;
    }

    public RequestLinkDto() {
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
