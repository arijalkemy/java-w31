package com.mercadolibre.tracker.repository;

import com.mercadolibre.tracker.model.Link;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class LinkRepositoryImpl implements LinkRepository {

    private List<Link> links = new ArrayList<>();


    @Override
    public String createLink(Link link) {
        links.add(link);
        return link.getLinkId();
    }
}
