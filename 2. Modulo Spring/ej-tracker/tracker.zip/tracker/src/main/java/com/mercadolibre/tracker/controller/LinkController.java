package com.mercadolibre.tracker.controller;

import com.mercadolibre.tracker.dto.RequestLinkDto;
import com.mercadolibre.tracker.dto.ResponseLinkDto;
import com.mercadolibre.tracker.service.LinkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class LinkController {

    @Autowired
    LinkService linkService;

    @PostMapping("/link")
    public ResponseEntity<ResponseLinkDto> createLink(@RequestBody RequestLinkDto requestLink) {
        return new ResponseEntity<>(linkService.createLink(requestLink), HttpStatus.CREATED);
    }

    @GetMapping("/link/{linkId}")
    public ResponseEntity<ResponseLinkDto> redirect(@PathVariable String linkId) {
        return new ResponseEntity<>(linkService.redirect(linkId), HttpStatus.PERMANENT_REDIRECT);
    }
}
