package com.mercadolibre.tracker.repository;

import com.mercadolibre.tracker.model.Link;

public interface LinkRepository {

    String createLink(Link link);
}
