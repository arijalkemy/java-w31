package com.mercadolibre.tracker.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mercadolibre.tracker.dto.RequestLinkDto;
import com.mercadolibre.tracker.dto.ResponseLinkDto;
import com.mercadolibre.tracker.model.Link;
import com.mercadolibre.tracker.repository.LinkRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LinkServiceImpl implements LinkService {

    @Autowired
    LinkRepository linkRepository;
    @Override
    public ResponseLinkDto createLink(RequestLinkDto requestLink) {
        Link link = new Link(String.valueOf(Math.random()), requestLink.getUrl(), Boolean.TRUE, 0, null);

        return new ResponseLinkDto(linkRepository.createLink(link));
    }
}
