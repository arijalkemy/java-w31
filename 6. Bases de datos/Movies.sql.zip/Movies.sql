/*Agregar una película a la tabla movies.*/
INSERT INTO movies
VALUES (22,NULL, NULL, 'Perdidos en Tokio', 7.7, 2, '2003-09-12 00:00:00', 102, 4);

/*Agregar un género a la tabla genres.*/
INSERT INTO genres
VALUES (13,'2014-07-04 03:00:00',NULL,'PostApocaliptico',13,1);

/*Asociar a la película del punto 1. genre el género creado en el punto 2.*/
UPDATE movies
SET genre_id = 13
WHERE id = 22;
/*Crear una tabla temporal copia de la tabla movies.*/
CREATE TEMPORARY TABLE moviesV2 AS SELECT * FROM movies;
SELECT * FROM moviesV2;

/*Eliminar de esa tabla temporal todas las películas que hayan ganado menos de 5 awards.*/
DELETE FROM moviesV2
WHERE awards < 5;

/*Obtener la lista de todos los géneros que tengan al menos una película.*/
SELECT DISTINCT g.*
FROM genres g
JOIN movies m ON g.id = m.genre_id;

/*Obtener la lista de actores cuya película favorita haya ganado más de 3 awards.*/
SELECT a.* FROM actors a
JOIN movies m ON a.favorite_movie_id = m.id
WHERE m.awards>3;

/*Crear un índice sobre el nombre en la tabla movies.*/
CREATE INDEX idx_title ON movies(title);

/*Chequee que el índice fue creado correctamente*/
SHOW INDEX FROM movies;
