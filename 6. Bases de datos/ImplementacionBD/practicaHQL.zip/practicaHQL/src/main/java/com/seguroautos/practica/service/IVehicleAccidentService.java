package com.seguroautos.practica.service;

import com.seguroautos.practica.dto.VehicleAccidentDto;

import java.util.List;

public interface IVehicleAccidentService {


    // Listar las patentes de todos los vehículos registrados.
    List<VehicleAccidentDto> getAllVehiclePlates();

    // Listar la patente y la marca de todos los vehículos ordenados por año de fabricación.
    List<VehicleAccidentDto> getVehiclePlateAndBrandOrderedByYear();

    // Listar la patente de todos los vehículos que tengan más de cuatro ruedas y hayan sido fabricados en el corriente año.
    List<VehicleAccidentDto> getPlatesWithMoreThanFourWheelsFromCurrentYear();

    // Listar la matrícula, marca y modelo de todos los vehículos que hayan tenido un siniestro con pérdida mayor de 10000 pesos.
    List<VehicleAccidentDto> getVehiclesWithAccidentLossGreaterThan10000();

    // Listar la matrícula, marca y modelo de todos los vehículos que hayan tenido un siniestro con pérdida mayor de 10000 pesos
    // y mostrar a cuánto ascendió la pérdida total de todos ellos.
    List<VehicleAccidentDto> getVehiclesAndTotalLossWhereAccidentLossGreaterThan10000();

}
