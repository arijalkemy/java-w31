package com.seguroautos.practica.mapper;

import com.seguroautos.practica.dto.VehicleAccidentDto;

import java.util.List;

public class VehicleAccidentMapper {

    public static List<VehicleAccidentDto> getVehiclesAndTotalLossWhereAccidentLossGreaterThan10000(List<Object[]>  vehicleAccidentLosses) {

        return null;

    }

}
