package com.seguroautos.practica.repository;

import com.seguroautos.practica.entities.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IVehicleRespository extends JpaRepository<Vehicle, Long> {
}
