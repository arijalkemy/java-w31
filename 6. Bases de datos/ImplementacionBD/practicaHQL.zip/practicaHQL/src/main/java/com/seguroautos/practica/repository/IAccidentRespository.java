package com.seguroautos.practica.repository;

import com.seguroautos.practica.entities.Accident;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IAccidentRespository extends JpaRepository<Accident, Long> {
}
