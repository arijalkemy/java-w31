package com.seguroautos.practica.repository;

import com.seguroautos.practica.entities.Accident;
import com.seguroautos.practica.entities.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IVehicleAccidentRespository extends JpaRepository<Vehicle, Long> {

    // Listar las patentes de todos los vehículos registrados.
    @Query("SELECT v.licensePlate FROM Vehicle v")
    List<String> findAllVehiclePlates();

    // Listar la patente y la marca de todos los vehículos ordenados por año de fabricación.
    @Query("SELECT v.licensePlate FROM Vehicle v order by v.yearOfManufacture")
    List<Object[]> findVehiclePlateAndBrandOrderedByYear();

    // Listar la patente de todos los vehículos que tengan más de cuatro ruedas y hayan sido fabricados en el corriente año.
    @Query("SELECT v.licensePlate FROM Vehicle v WHERE v.numberOfWheels > 4 AND v.yearOfManufacture = 2025")
    List<String> findPlatesWithMoreThanFourWheelsFromCurrentYear();

    // Listar la matrícula, marca y modelo de todos los vehículos que hayan tenido un siniestro con pérdida mayor de 10000 pesos.
    @Query("SELECT v.licensePlate, v.brand , v.model  FROM Vehicle v JOIN v.incidents a WHERE a.economicLoss > 10000")
    List<Object[]> findVehiclesWithAccidentLossGreaterThan10000();

    // Listar la matrícula, marca y modelo de todos los vehículos que hayan tenido un siniestro con pérdida mayor de 10000 pesos
    // y mostrar a cuánto ascendió la pérdida total de todos ellos.
    @Query("SELECT v, s FROM Vehicle v JOIN v.incidents s WHERE s.economicLoss > 10000 GROUP BY v")
    List<Object[]> findVehiclesAndTotalLossWhereAccidentLossGreaterThan10000();
}
