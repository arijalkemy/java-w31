package com.seguroautos.practica.service.impl;

import com.seguroautos.practica.dto.VehicleAccidentDto;
import com.seguroautos.practica.repository.IVehicleAccidentRespository;
import com.seguroautos.practica.service.IVehicleAccidentService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class VehicleAccidentServiceImpl implements IVehicleAccidentService {

    private IVehicleAccidentRespository vehicleAccidentRespository;

    public VehicleAccidentServiceImpl(IVehicleAccidentRespository vehicleAccidentRespository) {
        this.vehicleAccidentRespository = vehicleAccidentRespository;
    }

    @Override
    public  List<VehicleAccidentDto> getAllVehiclePlates() {
        return null;
    }

    @Override
    public  List<VehicleAccidentDto> getVehiclePlateAndBrandOrderedByYear() {
        return null;
    }

    @Override
    public  List<VehicleAccidentDto> getPlatesWithMoreThanFourWheelsFromCurrentYear() {
        return null;
    }

    @Override
    public  List<VehicleAccidentDto> getVehiclesWithAccidentLossGreaterThan10000() {
        return null;
    }

    @Override
    public  List<VehicleAccidentDto> getVehiclesAndTotalLossWhereAccidentLossGreaterThan10000() {
        List<Object[]> vehicleAccidentLosses = this.vehicleAccidentRespository.findVehiclesAndTotalLossWhereAccidentLossGreaterThan10000();
        List<VehicleAccidentDto> vehicleAccidentDtos = new ArrayList<>();
        return null;
    }
}
