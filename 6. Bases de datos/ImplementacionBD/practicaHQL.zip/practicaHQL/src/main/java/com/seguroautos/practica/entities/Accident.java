package com.seguroautos.practica.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@Table(name="accidents")
@Entity
public class Accident {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long incidentId;

    private LocalDate incidentDate;
    private BigDecimal economicLoss;

    @ManyToOne
    @JoinColumn(name = "vehicle_id", nullable = false)
    private Vehicle reportedVehicleId;

}
