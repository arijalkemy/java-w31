package com.seguroautos.practica.controller;

import com.seguroautos.practica.dto.VehicleAccidentDto;
import com.seguroautos.practica.service.impl.VehicleAccidentServiceImpl;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/vehicles")
public class VehicleAccidentController {

    private final VehicleAccidentServiceImpl vehicleAccidentService;

    public VehicleAccidentController(VehicleAccidentServiceImpl vehicleAccidentService) {
        this.vehicleAccidentService = vehicleAccidentService;
    }

    // 1) Listar las patentes de todos los vehículos registrados.
    @GetMapping("/plates")
    public List<VehicleAccidentDto> getAllVehiclePlates() {
        return vehicleAccidentService.getAllVehiclePlates();
    }

    // 2) Listar la patente y la marca de todos los vehículos ordenados por año de fabricación.
    @GetMapping("/plates-brands")
    public List<VehicleAccidentDto> getVehiclePlateAndBrandOrderedByYear() {
        return vehicleAccidentService.getVehiclePlateAndBrandOrderedByYear();
    }

    // 3) Listar la patente de todos los vehículos con más de cuatro ruedas fabricados en el año actual.
    @GetMapping("/plates/more-than-four-wheels")
    public  List<VehicleAccidentDto> getPlatesWithMoreThanFourWheelsFromCurrentYear() {
        return vehicleAccidentService.getPlatesWithMoreThanFourWheelsFromCurrentYear();
    }

    // 4) Listar vehículos que hayan tenido siniestros con pérdida mayor a 10000 pesos.
    @GetMapping("/accidents/loss-greater-10000")
    public List<VehicleAccidentDto> getVehiclesWithAccidentLossGreaterThan10000() {
        return vehicleAccidentService.getVehiclesWithAccidentLossGreaterThan10000();
    }

    // 5) Listar vehículos y la pérdida total cuando hayan tenido siniestros con pérdida mayor a 10000 pesos.
    @GetMapping("/accidents/total-loss-greater-10000")
    public List<VehicleAccidentDto> getVehiclesAndTotalLossWhereAccidentLossGreaterThan10000() {
        return vehicleAccidentService.getVehiclesAndTotalLossWhereAccidentLossGreaterThan10000();
    }
}
