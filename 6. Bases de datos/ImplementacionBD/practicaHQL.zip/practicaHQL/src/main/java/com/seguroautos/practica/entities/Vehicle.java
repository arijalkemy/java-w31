package com.seguroautos.practica.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Table(name="vehicles")
@Entity
public class Vehicle {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long vehicleId;

    private String licensePlate;
    private String brand;
    private String model;
    private int yearOfManufacture;
    private int numberOfWheels;

    @OneToMany(mappedBy = "reportedVehicleId")
    private List<Accident> incidents;

    //extends JpaRepository<MiniSerie, Long>

}
