package com.seguroautos.practica.dto;

import com.seguroautos.practica.entities.Vehicle;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VehicleAccidentDto {
    private Vehicle vehicle;
    private Long incidentCount;

    public VehicleAccidentDto(Vehicle vehicle, Long incidentCount) {
        this.vehicle = vehicle;
        this.incidentCount = incidentCount;
    }


}
