package com.seguroautos.practica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeguroautosApplicationTests {

	@Test
	void contextLoads() {
	}

}
