package com.example.jpaHibernate.service;

import com.example.jpaHibernate.dto.UsuarioCreacionDTO;
import com.example.jpaHibernate.dto.UsuarioDTO;

import java.util.List;
import java.util.Optional;

public interface IUsuarioService {
    
    UsuarioDTO guardar(UsuarioCreacionDTO usuarioDTO);
    
    UsuarioDTO actualizar(Long id, UsuarioDTO usuarioDTO);
    
    List<UsuarioDTO> obtenerTodos();
    
    Optional<UsuarioDTO> obtenerPorId(Long id);
    
    Optional<UsuarioDTO> obtenerPorEmail(String email);
    
    List<UsuarioDTO> buscarPorNombreOApellido(String texto);
    
    List<UsuarioDTO> obtenerUsuariosActivos();
    
    List<UsuarioDTO> buscarPorTerminacionEmail(String terminacion);
    
    List<UsuarioDTO> obtenerUltimosUsuariosActivos();
    
    void eliminar(Long id);
} 