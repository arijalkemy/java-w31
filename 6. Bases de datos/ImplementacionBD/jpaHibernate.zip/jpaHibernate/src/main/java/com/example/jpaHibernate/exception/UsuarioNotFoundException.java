package com.example.jpaHibernate.exception;

public class UsuarioNotFoundException extends RuntimeException {
    
    public UsuarioNotFoundException(String message) {
        super(message);
    }
    
    public UsuarioNotFoundException(Long id) {
        super("No se encontró el usuario con ID: " + id);
    }
} 