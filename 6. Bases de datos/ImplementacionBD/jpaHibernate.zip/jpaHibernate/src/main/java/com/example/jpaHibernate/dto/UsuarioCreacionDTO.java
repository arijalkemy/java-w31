package com.example.jpaHibernate.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UsuarioCreacionDTO {
    private String nombre;
    private String apellido;
    private String email;
    private String password;
} 