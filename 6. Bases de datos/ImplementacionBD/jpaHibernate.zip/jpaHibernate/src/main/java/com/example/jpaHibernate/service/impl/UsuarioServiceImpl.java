package com.example.jpaHibernate.service.impl;

import com.example.jpaHibernate.dto.UsuarioCreacionDTO;
import com.example.jpaHibernate.dto.UsuarioDTO;
import com.example.jpaHibernate.entity.Usuario;
import com.example.jpaHibernate.exception.UsuarioNotFoundException;
import com.example.jpaHibernate.mapper.UsuarioMapper;
import com.example.jpaHibernate.repository.IUsuarioRepository;
import com.example.jpaHibernate.service.IUsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class UsuarioServiceImpl implements IUsuarioService {

    private final IUsuarioRepository usuarioRepository;
    private final UsuarioMapper usuarioMapper;
    
    @Autowired
    public UsuarioServiceImpl(IUsuarioRepository usuarioRepository, UsuarioMapper usuarioMapper) {
        this.usuarioRepository = usuarioRepository;
        this.usuarioMapper = usuarioMapper;
    }
    
    @Override
    @Transactional
    public UsuarioDTO guardar(UsuarioCreacionDTO usuarioDTO) {
        Usuario usuario = usuarioMapper.creacionDtoToEntity(usuarioDTO);
        Usuario usuarioGuardado = usuarioRepository.save(usuario);
        return usuarioMapper.entityToDto(usuarioGuardado);
    }
    
    @Override
    @Transactional
    public UsuarioDTO actualizar(Long id, UsuarioDTO usuarioDTO) {
        Usuario usuarioExistente = usuarioRepository.findById(id)
                .orElseThrow(() -> new UsuarioNotFoundException(id));
        
        usuarioExistente.setNombre(usuarioDTO.getNombre());
        usuarioExistente.setApellido(usuarioDTO.getApellido());
        usuarioExistente.setEmail(usuarioDTO.getEmail());
        usuarioExistente.setActivo(usuarioDTO.getActivo());
        
        Usuario usuarioActualizado = usuarioRepository.save(usuarioExistente);
        return usuarioMapper.entityToDto(usuarioActualizado);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<UsuarioDTO> obtenerTodos() {
        List<Usuario> usuarios = usuarioRepository.findAll();
        return usuarioMapper.entityListToDtoList(usuarios);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Optional<UsuarioDTO> obtenerPorId(Long id) {
        return usuarioRepository.findById(id)
                .map(usuarioMapper::entityToDto);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Optional<UsuarioDTO> obtenerPorEmail(String email) {
        return usuarioRepository.findByEmail(email)
                .map(usuarioMapper::entityToDto);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<UsuarioDTO> buscarPorNombreOApellido(String texto) {
        List<Usuario> usuarios = usuarioRepository.findByNombreContainingOrApellidoContaining(texto, texto);
        return usuarioMapper.entityListToDtoList(usuarios);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<UsuarioDTO> obtenerUsuariosActivos() {
        List<Usuario> usuarios = usuarioRepository.findByActivoTrue();
        return usuarioMapper.entityListToDtoList(usuarios);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<UsuarioDTO> buscarPorTerminacionEmail(String terminacion) {
        List<Usuario> usuarios = usuarioRepository.buscarPorTerminacionEmail(terminacion);
        return usuarioMapper.entityListToDtoList(usuarios);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<UsuarioDTO> obtenerUltimosUsuariosActivos() {
        List<Usuario> usuarios = usuarioRepository.obtenerUltimosUsuariosActivos();
        return usuarioMapper.entityListToDtoList(usuarios);
    }
    
    @Override
    @Transactional
    public void eliminar(Long id) {
        if (!usuarioRepository.existsById(id)) {
            throw new UsuarioNotFoundException(id);
        }
        usuarioRepository.deleteById(id);
    }
} 