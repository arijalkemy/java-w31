package com.example.jpaHibernate.mapper;

import com.example.jpaHibernate.dto.UsuarioCreacionDTO;
import com.example.jpaHibernate.dto.UsuarioDTO;
import com.example.jpaHibernate.entity.Usuario;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class UsuarioMapper {

    public UsuarioDTO entityToDto(Usuario usuario) {
        if (usuario == null) {
            return null;
        }
        
        UsuarioDTO dto = new UsuarioDTO();
        dto.setId(usuario.getId());
        dto.setNombre(usuario.getNombre());
        dto.setApellido(usuario.getApellido());
        dto.setEmail(usuario.getEmail());
        dto.setActivo(usuario.getActivo());
        dto.setFechaCreacion(usuario.getFechaCreacion());
        
        return dto;
    }
    
    public List<UsuarioDTO> entityListToDtoList(List<Usuario> usuarios) {
        return usuarios.stream()
                .map(this::entityToDto)
                .collect(Collectors.toList());
    }
    
    public Usuario creacionDtoToEntity(UsuarioCreacionDTO dto) {
        if (dto == null) {
            return null;
        }
        
        Usuario usuario = new Usuario();
        usuario.setNombre(dto.getNombre());
        usuario.setApellido(dto.getApellido());
        usuario.setEmail(dto.getEmail());
        usuario.setPassword(dto.getPassword());
        usuario.setActivo(true);
        
        return usuario;
    }
    
    public Usuario dtoToEntity(UsuarioDTO dto) {
        if (dto == null) {
            return null;
        }
        
        Usuario usuario = new Usuario();
        usuario.setId(dto.getId());
        usuario.setNombre(dto.getNombre());
        usuario.setApellido(dto.getApellido());
        usuario.setEmail(dto.getEmail());
        usuario.setActivo(dto.getActivo());
        usuario.setFechaCreacion(dto.getFechaCreacion());
        
        return usuario;
    }
} 