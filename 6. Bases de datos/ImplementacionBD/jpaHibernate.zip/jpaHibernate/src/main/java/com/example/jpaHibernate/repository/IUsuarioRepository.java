package com.example.jpaHibernate.repository;

import com.example.jpaHibernate.entity.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface IUsuarioRepository extends JpaRepository<Usuario, Long> {
    
    Optional<Usuario> findByEmail(String email);
    
    List<Usuario> findByNombreContainingOrApellidoContaining(String nombre, String apellido);
    
    List<Usuario> findByActivoTrue();
    
    // JPQL
    @Query("SELECT u FROM Usuario u WHERE u.email LIKE %:terminacion%")
    List<Usuario> buscarPorTerminacionEmail(@Param("terminacion") String terminacion);
    
    // Nativa
    @Query(value = "SELECT * FROM usuarios WHERE activo = true ORDER BY fecha_creacion DESC LIMIT 5", 
           nativeQuery = true)
    List<Usuario> obtenerUltimosUsuariosActivos();
}

