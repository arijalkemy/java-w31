package com.bootcampW22.EjercicioGlobal.utils;

import com.bootcampW22.EjercicioGlobal.dto.VehicleDto;
import com.bootcampW22.EjercicioGlobal.entity.Vehicle;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;

public class VehicleFactory {
    private static final ObjectMapper mapper = new ObjectMapper();
    public static Vehicle createPorscheCarreraGT = new Vehicle(99L, "Porsche", "Carrera GT", "8032", "Orange", 2005, "194", 1, "diesel", "automatic", 261.99, 10.2, 185.7);
    public static Vehicle createPorsche928 = new Vehicle(165L, "Porsche", "928", "7873", "Indigo", 1986, "116", 6, "biodiesel", "automatic", 134.12, 180.09, 242.29);
    public static Vehicle createLexusIS = new Vehicle(382L, "Lexus", "IS", "4", "Yellow", 2009, "110", 5, "biodiesel", "automatic", 176.45, 170.04, 169.23);


    public static VehicleDto convertToVehicleDto(Vehicle vehicle) {
        return mapper.convertValue(vehicle, VehicleDto.class);
    }

    public static List<VehicleDto> convertListVehicleDto(List<Vehicle> vehicleList){
        return vehicleList.stream().map(VehicleFactory::convertToVehicleDto).toList();
    }
}