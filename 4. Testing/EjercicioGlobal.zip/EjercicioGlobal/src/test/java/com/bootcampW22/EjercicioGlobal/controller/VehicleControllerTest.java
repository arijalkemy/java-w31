package com.bootcampW22.EjercicioGlobal.controller;

import com.bootcampW22.EjercicioGlobal.dto.VehicleAvgCapacityByBrandDto;
import com.bootcampW22.EjercicioGlobal.entity.Vehicle;
import com.bootcampW22.EjercicioGlobal.repository.IVehicleRepository;
import com.bootcampW22.EjercicioGlobal.utils.JsonUtils;
import com.bootcampW22.EjercicioGlobal.utils.VehicleFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class VehicleControllerTest {
    @Autowired
    MockMvc mockMvc;
    @Autowired
    IVehicleRepository repository;

    private Vehicle porscheCarreraGT;
    private Vehicle porsche928;

    @BeforeEach
    void setUp(){
        porscheCarreraGT = VehicleFactory.createPorscheCarreraGT;
        porsche928 = VehicleFactory.createPorsche928;

        repository.save(porscheCarreraGT);
        repository.save(porsche928);
    }
    @Test
    @DisplayName("[SUCCESS] Get average capacity by brand")
    void getVehicle_shouldreturnAverageCapacity_WhenBrandExists() throws Exception{
        Double cap1 = Double.valueOf(porsche928.getPassengers());
        Double cap2 = Double.valueOf(porscheCarreraGT.getPassengers());
        Double capacity = (cap1+cap2)/2+0.07;

        VehicleAvgCapacityByBrandDto expected = new VehicleAvgCapacityByBrandDto(capacity);
        String result = JsonUtils.generateFromObject(expected);
        mockMvc.perform(get("/vehicles/average_capacity/brand/Porsche"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().json(result))
                .andExpect(jsonPath("$.average_capacity").value(capacity));
    }

}