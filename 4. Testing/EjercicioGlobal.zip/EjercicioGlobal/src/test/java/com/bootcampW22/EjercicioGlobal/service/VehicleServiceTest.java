package com.bootcampW22.EjercicioGlobal.service;

import com.bootcampW22.EjercicioGlobal.dto.VehicleAvgCapacityByBrandDto;
import com.bootcampW22.EjercicioGlobal.entity.Vehicle;
import com.bootcampW22.EjercicioGlobal.exception.NotFoundException;
import com.bootcampW22.EjercicioGlobal.repository.IVehicleRepository;
import com.bootcampW22.EjercicioGlobal.repository.VehicleRepositoryImpl;
import com.bootcampW22.EjercicioGlobal.utils.VehicleFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;


@ExtendWith(SpringExtension.class)
class VehicleServiceTest {
    @Mock
    VehicleRepositoryImpl repository;

    @InjectMocks
    VehicleServiceImpl service;

    private Vehicle porscheCarreragt;
    private Vehicle porsche928;
    private Vehicle lexusIS;

    @BeforeEach
    void setUp(){
        porscheCarreragt = VehicleFactory.createPorscheCarreraGT;
        porsche928 = VehicleFactory.createPorsche928;
        lexusIS =VehicleFactory.createLexusIS;
    }

    @Test
    @DisplayName("[SUCCESS] Get vehicle capacity by brand")
    void getvehicle_shouldreturnvehiclecapacity_whenbrandexists(){
        List<Vehicle> vehicles = List.of(porsche928, porscheCarreragt);
        when(repository.findVehiclesByBrand("Porsche")).thenReturn(vehicles);
        Double cap1 = Double.valueOf(porscheCarreragt.getPassengers());
        Double cap2 = Double.valueOf(porsche928.getPassengers());
        Double averageCapacity = (cap1+cap2)/2;

        VehicleAvgCapacityByBrandDto expect = new VehicleAvgCapacityByBrandDto(averageCapacity);
        VehicleAvgCapacityByBrandDto result = service.calculateAvgCapacityByBrand("Porsche");

        assertAll(
                ()-> assertEquals(expect.getAverage_capacity(), result.getAverage_capacity()),
                ()-> assertNotNull(result)
        );
        verify(repository, times(1)).findVehiclesByBrand("Porsche");
        verifyNoMoreInteractions(repository);
    }
    @Test
    @DisplayName("[ERROR] Get vehicle capacity by brand Not found")
    void getvehicle_shouldreturnNovehiclecapacity_whenbrandNotFound() throws Exception{
        when(repository.findVehiclesByBrand("Baic")).thenReturn(List.of());

        NotFoundException exception = assertThrows(
                NotFoundException.class,
                ()->service.calculateAvgCapacityByBrand("Baic"),
                "ERROR: Ingrese una marca válida."
        );
        assertEquals("No se encontraron vehículos de esa marca.", exception.getMessage());

        verify(repository,times(1)).findVehiclesByBrand("Baic");
        verifyNoMoreInteractions(repository);
    }
}